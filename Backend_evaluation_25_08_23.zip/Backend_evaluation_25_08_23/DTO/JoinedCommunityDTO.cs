﻿namespace WebApplicationMySql.DTO
{
    public class JoinedCommunityDTO
    {
        public int? UserId { get; set; }

        public int? CommunityId { get; set; }
    }
}
