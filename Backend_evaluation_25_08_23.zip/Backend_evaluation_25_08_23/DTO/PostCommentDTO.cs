﻿namespace WebApplicationMySql.DTO
{
    public class PostCommentDTO
    {

        public int? PostId { get; set; }

        public int? UserId { get; set; }

        public string? CommentContent { get; set; }


    }
}
