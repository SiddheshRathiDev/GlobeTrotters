﻿namespace WebApplicationMySql.DTO
{
    public class InterestedDTO
    {
        public int InterestedId { get; set; }

        public int? UserId { get; set; }

        public int? TripId { get; set; }
    }
}
