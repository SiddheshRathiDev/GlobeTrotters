﻿namespace WebApplicationMySql.DTO
{
    public class ConversationDTO
    {
        public int ConversationId { get; set; }

        public int? UserOne { get; set; }

        public int? UserTwo { get; set; }

    }
}
