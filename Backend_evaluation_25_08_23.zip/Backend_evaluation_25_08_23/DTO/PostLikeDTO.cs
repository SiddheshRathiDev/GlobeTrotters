﻿namespace WebApplicationMySql.DTO
{
    public class PostLikeDTO
    {
        public int? PostId { get; set; }

        public int UserId { get; set; }
    }
}
