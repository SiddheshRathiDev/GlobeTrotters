﻿namespace WebApplicationMySql.DTO
{
    public class CommunityDTO
    {
        public int? AdminUserId { get; set; }
    }
}
