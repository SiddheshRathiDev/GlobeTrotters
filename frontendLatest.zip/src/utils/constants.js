export const constants = {
    serverUrl : 'https://localhost:7118',
    
}