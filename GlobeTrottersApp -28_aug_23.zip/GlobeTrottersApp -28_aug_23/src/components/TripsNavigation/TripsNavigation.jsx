import { useContext, useState } from "react";
import "./TripsNavigation.scss";
import { AuthContext } from "../../context/authContext";
import { Button, Container, Typography } from "@mui/material";

const Stories = () => {
  const { currentUser } = useContext(AuthContext);
  const { followerStoryId, setStory } = useState([1, 2]);

  const [showModal, setShowModal] = useState(false);
  const [data,setData] = useState([]);

  const handleClick = () => {
    console.log("batman");
    setShowModal(true);
  };

  


  //TEMPORARY
  const stories = [
    {
      id: 1,
      name: "Prasad",
      img: "https://images.pexels.com/photos/13916254/pexels-photo-13916254.jpeg?auto=compress&cs=tinysrgb&w=1600&lazy=load",
    },
    {
      id: 2,
      name: "Hitesh",
      img: "https://images.pexels.com/photos/13916254/pexels-photo-13916254.jpeg?auto=compress&cs=tinysrgb&w=1600&lazy=load",
    },
    {
      id: 3,
      name: "Shardul",
      img: "https://images.pexels.com/photos/13916254/pexels-photo-13916254.jpeg?auto=compress&cs=tinysrgb&w=1600&lazy=load",
    },
    {
      id: 4,
      name: "Saurabh",
      img: "https://images.pexels.com/photos/13916254/pexels-photo-13916254.jpeg?auto=compress&cs=tinysrgb&w=1600&lazy=load",
    },
  ];

  return (
    <div className="stories">
      <div className="story">
        <img
          src={"http://localhost:9999/api/posts/get_post_image/2"}
          onClick={handleClick}
        />
        <span>PRASAD</span>
      </div>

      {showModal && (
        <div style={{ zIndex: 1 }}>
          <Button
            variant="contained"
            color="error"
            onClick={() => setShowModal(false)}
          >
            Close
          </Button>
          <img
            src={"http://localhost:9999/api/posts/get_post_image/2"}
            alt=""
            onClick={() => setShowModal(false)}
          />
          <Typography
            sx={{
              width: "100%",
              backgroundColor: "white",
              fontStyle: "italic",
            }}
            variant="h3"
            gutterBottom
          >
            PRASAD
          </Typography>
        </div>
      )}

      <div className="story">
        <img src={currentUser.profilePic} alt="" onClick={handleClick} />
        <span>{currentUser.name}</span>
        <button>+</button>
      </div>

      {stories.map((story) => (
        <div className="story" key={story.id}>
          <img src={story.img} alt="" />
          <span>{story.name}</span>
        </div>
      ))}

    </div>
  );
};

export default Stories;
