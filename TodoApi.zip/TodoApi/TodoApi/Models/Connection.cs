﻿using System;
using System.Collections.Generic;

namespace Dacproject.Models;

public partial class Connection
{
    public int ConnectionId { get; set; }

    public int? UserFollower { get; set; }

    public int? UserFollowing { get; set; }

    public string? Extra1 { get; set; }

    public string? Extra2 { get; set; }

    public virtual User? UserFollowerNavigation { get; set; }

    public virtual User? UserFollowingNavigation { get; set; }
}
