﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Dacproject.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Dacproject.Data;
using TodoApi.Models.DTOs;

namespace GlobeTrotters.Controllers
{
    [Route("api/posts")]
    [ApiController]
    public class PostsController : ControllerBase
    {
        private readonly DacprojectContext _context;

        public PostsController(DacprojectContext context)
        {
            _context = context;
        }

        // GET: api/posts
        [HttpGet]
        public async Task<ActionResult<IEnumerable<PostDTO>>> GetPosts()
        {
            var posts = await _context.Posts
                .Select(post => new PostDTO
                {
                    PhotoUrl = post.PhotoUrl,
                    Caption = post.Caption,
                    Latitude = post.Latitude,
                    Longitude = post.Longitude,
                    LocationName = post.LocationName
                })
                .ToListAsync();

            return posts;
        }

        // POST: api/posts
        [HttpPost]
        public async Task<ActionResult<PostDTO>> CreatePost([FromForm] PostDTO postDTO)
        {

            //int currentUserId = await _context.Users
            //                    .Select(user => new User
            //                    {
            //                        currentUserId = user.UserId,
            //                    })/* Get the current user's ID from your authentication */;

            // Process and store the image file
            int? currentUserId = null;
            string imageFileName = null;
            if (postDTO.ImageFile != null)
            {
                // Generate a unique image filename (you can use a GUID, timestamp, etc.)
                imageFileName = $"{Guid.NewGuid().ToString()}_{DateTime.UtcNow.Ticks.ToString()}.jpg";
                
                // Construct the path to store the image
                string imagePath = Path.Combine("Images", imageFileName);

                // Save the image to the server's file system
                using (var stream = new FileStream(imagePath, FileMode.Create))
                {
                    await postDTO.ImageFile.CopyToAsync(stream);
                }
            }

            var post = new Post
            {
                UserId = postDTO.UserId,
                PhotoUrl = imageFileName,
                Caption = postDTO.Caption,
                Latitude = postDTO.Latitude,
                Longitude = postDTO.Longitude,
                LocationName = postDTO.LocationName,
                CreatedDatetime = DateTime.UtcNow
            };

            _context.Posts.Add(post);
            await _context.SaveChangesAsync();

           
            return Ok(post);
        }

    }
}
